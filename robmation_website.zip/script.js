// You can add animations or effects here later
console.log("Robmation Automation Website Loaded");